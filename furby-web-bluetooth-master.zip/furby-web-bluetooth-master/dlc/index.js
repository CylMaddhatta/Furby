[
    { 
        "file": "context.dlc", 
        "title": "Context Logo",
        "buttons": [
            { "title": "Logo", "action": [75,0,4,4] }
        ]
    },
    { 
        "file": "hacked.dlc", 
        "title": "HACKED",
        "buttons": [
            { "title": "Hacked 1", "action": [75,0,3,4] },
            { "title": "Hacked 2", "action": [75,0,4,4] }
        ]
    },
    {
        "file": "noimg2.dlc", 
        "title": "Audio only",
        "buttons": [
            { "title": "Audio test ", "action": [75,0,4,4] }
        ]
    },
    {
        "file": "chilli.dlc", 
        "title": "Chilli",
        "buttons": [
            { "title": "Chilli ", "action": [75,0,4,4] }
        ]
    }
]